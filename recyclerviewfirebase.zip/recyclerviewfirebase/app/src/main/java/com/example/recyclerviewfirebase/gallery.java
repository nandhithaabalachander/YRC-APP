package com.example.recyclerviewfirebase;

public class gallery
{
    // Variable to store data corresponding
    // to firstname keyword in database
    private String name;

    private String image;

    // Mandatory empty constructor
    // for use of FirebaseUI
    public gallery() {}

    // Getter and setter method
    public String getimage()
    {
        return image;
    }
    public void setimage(String image)
    {
        this.image = image;
    }
}
