package com.example.recyclerviewfirebase;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.squareup.picasso.Picasso;

public class galleryAdapter extends FirebaseRecyclerAdapter<
        gallery, galleryAdapter.galleryViewholder> {

    public galleryAdapter(
            @NonNull FirebaseRecyclerOptions<gallery> options)
    {
        super(options);
    }
    @Override
    protected void
    onBindViewHolder(@NonNull galleryViewholder holder,
                     int position, @NonNull gallery model)
    {
        Picasso.get()
                .load(model.getimage())
                .fit()
                .centerCrop()
                .into(holder.image);
    }

    // Function to tell the class about the Card view (here
    // "person.xml")in
    // which the data will be shown
    @NonNull
    @Override
    public galleryViewholder
    onCreateViewHolder(@NonNull ViewGroup parent,
                       int viewType)
    {

        View view
                = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.gallery, parent, false);
        return new galleryViewholder(view);
    }

    // Sub Class to create references of the views in Crad
    // view (here "person.xml")
    class galleryViewholder
            extends RecyclerView.ViewHolder {
        ImageView image;
        public galleryViewholder(@NonNull View itemView)
        {
            super(itemView);

            image = itemView.findViewById(R.id.image);
        }
    }
}