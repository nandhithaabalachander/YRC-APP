package com.example.recyclerviewfirebase;


import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class NewActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    galleryAdapter  adapter4;
    DatabaseReference mbase;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        mbase = FirebaseDatabase.getInstance().getReference().child("gallery");
        recyclerView = findViewById(R.id.recycler3);

        // To display the Recycler view linearly
        recyclerView.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));


        // It is a class provide by the FirebaseUI to make a
        // query in the database to fetch appropriate data
        FirebaseRecyclerOptions<gallery> options1
                = new FirebaseRecyclerOptions.Builder<gallery>()
                .setQuery(mbase, gallery.class)
                .build();
        // Connecting object of required Adapter class to
        // the Adapter class itself
        adapter4 = new galleryAdapter(options1);
        // Connecting Adapter class with the Recycler view*/
        recyclerView.setAdapter(adapter4);
    }


    // Function to tell the app to start getting
    // data from database on starting of the activity
    @Override protected void onStart()
    {
        super.onStart();
        adapter4.startListening();
    }

    // Function to tell the app to stop getting
    // data from database on stoping of the activity
    @Override protected void onStop()
    {
        super.onStop();
        adapter4.stopListening();
    }
    public void openNewActivity(){
        Intent intent = new Intent(this, NewActivity.class);
        startActivity(intent);
    }
}